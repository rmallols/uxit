(function () {
    'use strict';
    COMPONENTS.service('helloWorldAppService', [function () {

        function view(scope) {
			console.log("hello world view");
        }
		
		function edit(scope) {
			console.log("hello world edit");
        }

        return {
            view: view,
			edit: edit
        };
    }]);
})();
